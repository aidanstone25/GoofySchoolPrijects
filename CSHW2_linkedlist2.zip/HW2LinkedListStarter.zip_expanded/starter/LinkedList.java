package starter;

import java.awt.Color;
import java.awt.Graphics2D;

public class LinkedList {

	/**
	 * The first Node in the list
	 */
	Node head;
	 
	/**
	 * The last Node in the list
	 */
	Node tail;

	/**
	 * Creates an empty list
	 */
	public LinkedList() {
		head = null;
		tail = null;
	}

	/**
	 * Creates a list with one node
	 * 
	 * @param n
	 */
	public LinkedList(Node n) {
		this.head = n;
		this.tail = n;
	}

	/**
	 * Inserts into the list if it's blank, otherwise does nothing.
	 * 
	 * Insertion is always a little different when the list is completely blank,
	 * other insertion functions utilize this one check if the list is blank and act
	 * accordingly
	 * 
	 * @param n
	 * @return - true if an insertion occurred, otherwise false
	 */
	public boolean insertIfEmpty(Node n) {
		if (head != null) {
			return false;
		} else {
			head = n;
			tail = n;
			return true;
		}
	}

	/**
	 * Inserts a Node at the tail. Cannot fail.
	 * 
	 * @param n
	 */
	public void insertAtTail(Node n) {
		if (insertIfEmpty(n)) {
			return;
		}
		tail.next = n;
		n.previous = tail;
		tail = n;
	}

	/**
	 * Inserts a node at the head. Cannot fail.
	 * 
	 * @param n
	 */
	public void insertAtHead(Node n) {
		if (insertIfEmpty(n)) {
			return;
		}
		head.previous = n;
		n.next = head;
		head = n;
	}
	/**
	 * removes a node from list, constant time
	 * @param input_node
	 */
	public void removeNode(Node input_node) {
		if(head == tail) {
			head = null;
			tail = null;
			input_node = null;
			return;
		}
		if(input_node == tail) {
			tail = tail.previous;
			tail.next = null;
			input_node = null;
			return;
		}
		if(input_node == head) {
			
			head= head.next;
			head.previous = null;
			input_node = null;
			return;
		}
		
		input_node.previous.next = input_node.next;
		input_node.next.previous = input_node.previous;
		input_node = null;
	}
	/**
	 * removes all nodes sharing color c
	 * @param c
	 */
	public void removeColors(Color c) {
		Node cur = head;
		if(cur == null) {
			return;
		}
		while(cur != tail) {
			if(cur.color == c) {
				removeNode(cur);
			}
			cur = cur.next;
			}
		if(tail.color == c) {
			removeNode(tail);
		}
	}
	 
	 /**
	  * reverses all elements in linked list, O(n)
	  */
	public void invertList() {
		if(head == null) {
			return;
		}
		Node curr = head;
		Node prev = null;

		while(curr != null) {
			prev = curr.previous;
			curr.previous = curr.next;
			curr.next = prev;
			curr = curr.previous;
		}
		Node placeholder = head;
		head = tail;
		tail = placeholder;
	}
		
	/**
	 * inserts a new node of color c after node n, O(1)
	 * @param n
	 * @param c
	 */
	public void insertAfterSelected(Node n,Color c) {
		Node linked = new Node(c);
		if(n == tail) {
			insertAtTail(linked);
			return;
			
		}
		Node curr = n.next;
		n.next = linked;
		linked.previous = n;
		linked.next = curr;
		curr.previous = linked;
		
	}
	
	/**
	 * inserts a new node of color c before node n, O(1)
	 * @param n
	 * @param c
	 */
	public void insertBeforeSelected(Node n,Color c) {
		Node linked = new Node(c);

		if(n == head) {
			insertAtHead(linked);
			return;
		}
		Node curr = n.previous;
		n.previous = linked;
		linked.next = n;
		linked.previous = curr;
		curr.next = linked;
		
		
	}
	
	/**
	 * Removes all nodes between nodes selected and clicked
	 * @param selected
	 * @param clicked
	 */
	public void cut(Node selected, Node clicked) {
		if(selected == clicked) {
			return;
		}
		Node curr = head;
		
		while(curr!= selected && curr!= clicked) {
			curr = curr.next;
		}
		
		if(selected == curr) {
			selected.next = clicked;
			clicked.previous = selected;
			}
		
		else {
			clicked.next = selected;
			selected.previous = clicked;
		}
		}
	/**
	 * Draws the list to the screen in a fancy spiral
	 * 
	 * @param g
	 */
	public void draw(Graphics2D g, int centerX, int centerY) {
		if (head == null) {
			return;
		}

		final double THETA_STEP = Math.PI / 5;
		final double RADIUS_STEP = 4;
		final int NODE_SIZE = (int) NodeDisplay.NODE_SIZE;

		int x = centerX;
		int y = centerY;
		double radius = NODE_SIZE;
		double theta = 0;
		Node curr = head;
		while (curr != null) {
			curr.display.moveTo(x, y);
			x = (int) (centerX + Math.cos(theta) * radius);
			y = (int) (centerY + Math.sin(theta) * radius);
			radius += RADIUS_STEP;
			theta += THETA_STEP;
			curr = curr.next;
		}

		curr = head;
		while (curr != null) {
			curr.display.draw(g);
			curr = curr.next;
		}

	}

}
