package starter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.MouseInputListener;

public class Display extends JPanel implements MouseInputListener, KeyListener {

	LinkedList list = new LinkedList();
	Node coloredNode = list.head;
	ColorButton[] buttons = new ColorButton[13];
	Node selected = null;
	Color previousColor = null;
	boolean selectedmode = false;
	boolean is_button = false;
	boolean is_node = false;
	Color background_color = Color.black;

	/**
	 * Construct a panel with specified width, height, and background color
	 * 
	 * @param width
	 * @param height
	 * @param bgColor
	 */
	public Display(int width, int height, Color bgColor) {
		setPreferredSize(new Dimension(width, height));
		setBackground(bgColor);

		this.addMouseListener(this);
		this.addMouseMotionListener(this);

		this.addKeyListener(this);
		this.setFocusable(true);
		this.setFocusTraversalKeysEnabled(false);

		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new ColorButton(ColorButton.PADDING + i * (ColorButton.SIZE + ColorButton.PADDING),
					ColorButton.PADDING);
		}
	}

	protected void paintComponent(Graphics graphicHelper) {
		super.paintComponent(graphicHelper);
		Graphics2D g = (Graphics2D) graphicHelper;
		g.setPaint(background_color);
		g.drawRect(0, 0, 800, 800);
		g.fillRect(0, 0, 800, 800);
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].draw(g);
		}
		list.draw(g, this.getWidth() / 2, this.getHeight() / 2);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// DONT USE THIS ONE
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	/**
	 * runs various methods done with mouse click
	 */
	public void mousePressed(MouseEvent e) {
		for (int i = 0; i < buttons.length; i++) {
			if (buttons[i].contains(e.getPoint())) {
				Color c = buttons[i].getColor();
				if(SwingUtilities.isRightMouseButton(e) && !selectedmode) {
					list.removeColors(c);
					if(coloredNode == null) {
						coloredNode = list.head;
					}
				}
				else if(SwingUtilities.isLeftMouseButton(e)&& !selectedmode) {
					list.insertAtTail(new Node(c));
					if(coloredNode == null) {
						coloredNode = list.head;
					}
				}
				else if(SwingUtilities.isLeftMouseButton(e)&& selectedmode) {
					list.insertAfterSelected(selected,c);
					if(coloredNode == null) {
						coloredNode = list.head;
					}
				}
				else if(SwingUtilities.isRightMouseButton(e)&& selectedmode){
					list.insertBeforeSelected(selected,c);
					if(coloredNode == null) {
						coloredNode = list.head;
					}

				}
			is_button = true;
			}
		}
		
		Node curr = list.head;
		while (curr != null) {
			if (curr.display.contains(e.getPoint())) {
				
				if(SwingUtilities.isLeftMouseButton(e) && !selectedmode) {	
						list.removeNode(curr);
						if(coloredNode == null) {
							coloredNode = list.head;
						}
						
				}
				
				else if(SwingUtilities.isRightMouseButton(e) && !selectedmode) {
					selectedmode = true;
					selected = curr;
					previousColor = selected.color;
					selected.color = Color.white;		
				}
			
				
				else if(SwingUtilities.isRightMouseButton(e) && selectedmode) {
					list.cut(selected,curr);
					if(coloredNode == null) {
						coloredNode = list.head;
					}
					repaint();
					return;
				}
				
				is_node = true;
			}
			
			curr = curr.next;
		}
		if(!is_node && !is_button && selectedmode) {
			selectedmode = false;
			selected.color = previousColor;
		}
		is_button = false;
		is_node = false;
		repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

	@Override
	/**
	 * space: inverts list
	 * right&left: changes colored node which represents background color
	 */
	public void keyPressed(KeyEvent k) {
		 if(k.getKeyCode() == KeyEvent.VK_SPACE) {
			 list.invertList();
			 System.out.println(list);
		 }
		 else if(k.getKeyCode() == KeyEvent.VK_RIGHT) {
			 if(coloredNode.next != null) {
				 coloredNode = coloredNode.next;
				 background_color = coloredNode.color;
			 }
		 }
else if(k.getKeyCode() == KeyEvent.VK_LEFT) {
			 if(coloredNode.previous != null) {
				 coloredNode = coloredNode.previous;
				 background_color = coloredNode.color;
			 }
			 
		 }
		 repaint();
	}

	@Override
	public void keyReleased(KeyEvent k) {
		
	}

	@Override
	public void keyTyped(KeyEvent k) {
	}
}


