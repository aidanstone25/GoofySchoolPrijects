module cs229HW1P2 {
	requires java.desktop;
}