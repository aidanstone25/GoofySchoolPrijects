package HW1Starter;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.event.MouseInputListener;

public class Display extends JPanel implements MouseInputListener, KeyListener {

	CircularArray outer;
	CircularArray outer2;
	CircularArray inner;
	ColorButton[] buttons = new ColorButton[13];
	ArrayList<CircularArray> circles_list  = new ArrayList<CircularArray>(); 

	public static final double OUTER_RADIUS  = 150;
	public static final double INNER_RADIUS = 100;
	public static Color oldest= Color.BLACK;
	public static Color oldest2 = Color.BLACK;
	public static int array_size = 10;

	/**
	 * Construct a panel with specified width, height, and background color
	 * 
	 * @param width
	 * @param height
	 * @param bgColor
	 */
	public CircularArray addArray(int x) {
		
		outer2 = new CircularArray(array_size, this.getWidth() / 2 - Tile.TILE_SIZE / 2,
				this.getHeight() / 2 - Tile.TILE_SIZE / 2, INNER_RADIUS+(x*50));
		return outer2;

		
	}
	
	public Display(int width, int height, Color bgColor) {
		setPreferredSize(new Dimension(width, height));
		setBackground(bgColor);

		this.addMouseListener(this);
		this.addMouseMotionListener(this);

		this.addKeyListener(this);
		this.setFocusable(true);
		this.setFocusTraversalKeysEnabled(false);
	
		outer = new CircularArray(10, width / 2 - Tile.TILE_SIZE / 2,
				height / 2 - Tile.TILE_SIZE / 2, OUTER_RADIUS);
		inner = new CircularArray(10, width / 2 - Tile.TILE_SIZE / 2,
				height / 2 - Tile.TILE_SIZE / 2, INNER_RADIUS);
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new ColorButton(
					ColorButton.PADDING + i * (ColorButton.SIZE + ColorButton.PADDING),
					ColorButton.PADDING);
		}
		circles_list.add(inner);
		circles_list.add(outer);
	}

	protected void paintComponent(Graphics graphicHelper) {
		super.paintComponent(graphicHelper);
		Graphics2D g = (Graphics2D) graphicHelper;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		//g.setColor(oldest);
		Paint paint = new GradientPaint(0,0,oldest,800,800,oldest2);
		g.setPaint(paint);
		g.drawRect(0, 0, 800, 800);
		//g.fillArc(FRAMEBITS, ERROR, WIDTH, HEIGHT, ALLBITS, ABORT);
		g.fillRect(0, 0, 800, 800);
		for(int i = 0; i<circles_list.size();i++) {
			circles_list.get(i).draw(g);
		}
		//outer.draw(g);
		//inner.draw(g);
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].draw(g);
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// DONT USE THIS ONE
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	
	@Override
	/**
	 * If button is clicked then it checks if each list is full, then finds empty circle and tries fill method, linear time
	 * 
	 */
	public void mousePressed(MouseEvent e) {
		int array_counter = 0;
		for (int i = 0; i < buttons.length; i++) {
			if (buttons[i].contains(e.getPoint())) {
				Color c = buttons[i].getColor();
				for(int l = 0; l < circles_list.size(); l++) {
					
						if(circles_list.get(array_counter).isFull() == false) {
							circles_list.get(array_counter).push(c);
							break;
						}
						else {
							array_counter+=1;
							if(array_counter >= circles_list.size()) {
								circles_list.add(addArray(array_counter));
							}
						}
				
					
				}
				
				
			}
		}
		
		
		repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}
	/**
	 * finds oldest tile that is filled, then pops it and resets colors for background. Linear time
	 * Also resets size of the array for f,s,d,a
	 */
	@Override
	public void keyPressed(KeyEvent k) {
		if (k.getKeyCode() == KeyEvent.VK_A) {
			array_size = 10;
			respawnArrays(10);
		} else if (k.getKeyCode() == KeyEvent.VK_S) {
			array_size = 15;
			respawnArrays(15);
		} else if (k.getKeyCode() == KeyEvent.VK_D) {
			array_size = 20;
			respawnArrays(20);
		} else if (k.getKeyCode() == KeyEvent.VK_F) {
			array_size = 40;
			respawnArrays(40);
		} else if (k.getKeyCode() == KeyEvent.VK_SPACE) {
			for(int i=0; i <circles_list.size();i++) {
				if(circles_list.get(i).isEmpty() == false) {
					oldest2 = oldest;
					oldest = circles_list.get(i).pop();
					break;
				}
			}
		}
		repaint();
	}

	@Override
	public void keyReleased(KeyEvent k) {
	}

	@Override
	public void keyTyped(KeyEvent k) {
	}

	/**
	 * Resets both circular arrays and respawns them with the given size.
	 */
	public void respawnArrays(int size) {
		double x = getWidth() / 2 - Tile.TILE_SIZE / 2;
		double y = getHeight() / 2 - Tile.TILE_SIZE / 2;
		outer = new CircularArray(size, x, y, OUTER_RADIUS);
		inner = new CircularArray(size, x, y, INNER_RADIUS);
		circles_list.clear();
		circles_list.add(inner);
		circles_list.add(outer);
	}

}